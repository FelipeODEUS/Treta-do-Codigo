import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';

class batata extends Component{
  render(){
    return(
      <Button color="Red" title="App do Deus" ></Button>
      );
      }
      }
export default class App extends Component {
  render() {
    return (
    <View style={{marginTop:500}}>
    <batata/>
        <Button color="Red" title="App do Deus" ></Button>
    </View>
    );
  }
}